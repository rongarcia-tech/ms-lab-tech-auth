package cl.duoc.ms_auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MS_AuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(MS_AuthApplication.class, args);
	}


}
