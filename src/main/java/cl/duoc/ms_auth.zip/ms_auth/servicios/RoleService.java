package cl.duoc.ms_auth.servicios;

import cl.duoc.ms_auth.dtos.RoleResponse;

import java.util.List;

public interface RoleService {
    List<RoleResponse> list(); // ADMIN
}
