package cl.duoc.ms_auth.exceptions;

public class BadRequestException extends RuntimeException {
    public BadRequestException(String msg){ super(msg); }
}
