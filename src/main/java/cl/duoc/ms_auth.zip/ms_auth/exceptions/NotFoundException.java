package cl.duoc.ms_auth.exceptions;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String msg){ super(msg); }
}
