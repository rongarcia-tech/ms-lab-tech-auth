package cl.duoc.ms_auth.exceptions;

public class ConflictException extends RuntimeException {
    public ConflictException(String msg){ super(msg); }
}
